#pragma once

namespace wrap
{
	struct Rect
	{
		int x;
		int y;
		int w;
		int h;
	};
}