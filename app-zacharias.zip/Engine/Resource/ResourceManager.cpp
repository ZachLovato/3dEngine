#include "ResourceManager.h"

namespace wrap
{
	void ResourceManager::Initialize()
	{
		//
	}

	void ResourceManager::Shutdown()
	{
		m_resources.clear();
	}


}
